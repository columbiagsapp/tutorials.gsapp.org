<?php
<article>
    <header>
        <title>
          {{ title }}
        </title>
        {# Add a button element to toggle promote status #}
        <button value="<?php t('Promote'); ?>'" class="promote-toggle"/>
    </header>
    <div class="body">
      {{ body }}
    </div>
</article>
?>