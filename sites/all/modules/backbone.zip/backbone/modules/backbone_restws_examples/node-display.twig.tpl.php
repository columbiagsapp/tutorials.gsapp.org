<div class="article">
  <div class="title">
    {{ title }}
  </div>
  <div class="body">
    {{ body.value }}
  </div>
</div>
