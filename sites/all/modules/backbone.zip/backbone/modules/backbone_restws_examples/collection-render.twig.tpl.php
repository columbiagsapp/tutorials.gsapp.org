<h1>View Results</h1>
<ul class="search-results">
  {# Search results go here, via ViewCollection.render #}
</ul>
