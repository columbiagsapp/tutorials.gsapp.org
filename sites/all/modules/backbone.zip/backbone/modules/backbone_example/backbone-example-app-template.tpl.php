<form action="#" name="question-add-form" onSubmit="return false;">
	<div>
		<label for="nid">Node ID</label>
		<input type="textfield" name="nid" id="nid" />
    <input type="submit" value="load" />
  </div>
  <div id="new-question-container">
  </div>
</form>
